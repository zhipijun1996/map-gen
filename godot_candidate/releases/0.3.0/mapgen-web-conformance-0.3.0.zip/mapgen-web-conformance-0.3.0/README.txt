Local conformance export only; not a playable game or deployment.
Serve this directory with python3 -m http.server --bind 127.0.0.1 8000, then open http://127.0.0.1:8000/.
Result is available as window.mapgenReport in the browser console. No Python is used by generation.
