extends RefCounted
const REQUEST = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:mapgen:request:v1",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "schema",
    "seed",
    "player",
    "terminals",
    "start_origin_blocks",
    "module_filter",
    "air_loop"
  ],
  "properties": {
    "schema": {
      "const": "mapgen/generation-request/v1"
    },
    "seed": {
      "type": "integer"
    },
    "player": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "abilities",
        "clearance_half_extents_pixels"
      ],
      "properties": {
        "abilities": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "clearance_half_extents_pixels": {
          "type": "array",
          "minItems": 2,
          "maxItems": 2,
          "items": {
            "type": "number",
            "exclusiveMinimum": 0
          }
        }
      }
    },
    "terminals": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "start",
        "boss"
      ],
      "properties": {
        "start": {
          "type": "object",
          "additionalProperties": false,
          "required": [
            "module_id",
            "port_id"
          ],
          "properties": {
            "module_id": {
              "type": "string",
              "minLength": 1
            },
            "port_id": {
              "type": "string",
              "minLength": 1
            }
          }
        },
        "boss": {
          "type": "object",
          "additionalProperties": false,
          "required": [
            "module_id",
            "port_id"
          ],
          "properties": {
            "module_id": {
              "type": "string",
              "minLength": 1
            },
            "port_id": {
              "type": "string",
              "minLength": 1
            }
          }
        }
      }
    },
    "start_origin_blocks": {
      "type": "array",
      "minItems": 2,
      "maxItems": 2,
      "items": {
        "type": "integer"
      }
    },
    "module_filter": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "regions",
        "include_ids",
        "exclude_ids"
      ],
      "properties": {
        "regions": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "include_ids": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "exclude_ids": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        }
      }
    },
    "air_loop": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "enabled",
        "entry_module_ids",
        "return_module_ids"
      ],
      "properties": {
        "enabled": {
          "type": "boolean"
        },
        "entry_module_ids": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        },
        "return_module_ids": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          },
          "uniqueItems": true
        }
      }
    }
  }
}
const CONFIG = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:mapgen:config:v1",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "schema",
    "algorithm",
    "random",
    "goals",
    "shape",
    "scoring",
    "search",
    "seals",
    "diversity",
    "planning",
    "topology",
    "construction"
  ],
  "properties": {
    "schema": {
      "const": "mapgen/generator-config/v1"
    },
    "algorithm": {
      "const": "experimental-v7-joint-route-construction"
    },
    "random": {
      "const": {
        "algorithm": "python-mt19937-v1",
        "selection": "uniform_top_k"
      }
    },
    "goals": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "growth_target",
        "reward_target",
        "main_paths_required"
      ],
      "properties": {
        "growth_target": {
          "type": "integer",
          "minimum": 2
        },
        "reward_target": {
          "type": "integer",
          "minimum": 0
        },
        "main_paths_required": {
          "type": "integer",
          "minimum": 1
        }
      }
    },
    "shape": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "target_ratio",
        "soft_tolerance",
        "max_aspect"
      ],
      "properties": {
        "target_ratio": {
          "type": "number",
          "exclusiveMinimum": 0
        },
        "soft_tolerance": {
          "type": "number",
          "minimum": 1
        },
        "max_aspect": {
          "type": "number",
          "minimum": 1
        }
      }
    },
    "scoring": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "auto_connection",
        "repeat_module",
        "growth_noise",
        "perimeter",
        "aspect",
        "left_bias",
        "height_bias",
        "usable_exit",
        "bidirectional_exit",
        "terminal_slot",
        "dead_end",
        "vertical_exit",
        "distinct_direction",
        "reward_reserve",
        "reservation_repeat",
        "reservation_area",
        "reward_noise",
        "reward_near_radius",
        "reward_near_penalty",
        "closure_noise",
        "boss_distance"
      ],
      "properties": {
        "auto_connection": {
          "type": "number",
          "minimum": 0
        },
        "repeat_module": {
          "type": "number",
          "minimum": 0
        },
        "growth_noise": {
          "type": "number",
          "minimum": 0
        },
        "perimeter": {
          "type": "number",
          "minimum": 0
        },
        "aspect": {
          "type": "number",
          "minimum": 0
        },
        "left_bias": {
          "type": "number",
          "minimum": 0
        },
        "height_bias": {
          "type": "number",
          "minimum": 0
        },
        "usable_exit": {
          "type": "number",
          "minimum": 0
        },
        "bidirectional_exit": {
          "type": "number",
          "minimum": 0
        },
        "terminal_slot": {
          "type": "number",
          "minimum": 0
        },
        "dead_end": {
          "type": "number",
          "maximum": 0
        },
        "vertical_exit": {
          "type": "number",
          "minimum": 0
        },
        "distinct_direction": {
          "type": "number",
          "minimum": 0
        },
        "reward_reserve": {
          "type": "number",
          "minimum": 0
        },
        "reservation_repeat": {
          "type": "number",
          "minimum": 0
        },
        "reservation_area": {
          "type": "number",
          "minimum": 0
        },
        "reward_noise": {
          "type": "number",
          "minimum": 0
        },
        "reward_near_radius": {
          "type": "number",
          "minimum": 0
        },
        "reward_near_penalty": {
          "type": "number",
          "minimum": 0
        },
        "closure_noise": {
          "type": "number",
          "minimum": 0
        },
        "boss_distance": {
          "type": "number",
          "minimum": 0
        }
      }
    },
    "search": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "growth_frontier_limit",
        "growth_choice_count",
        "close_attempts",
        "close_depth",
        "closure_beam_width",
        "candidate_expansion_budget",
        "per_seed_timeout_seconds",
        "max_growth_backtracks",
        "max_rewind_depth",
        "max_terminal_states",
        "max_layout_repairs",
        "growth_shortlist",
        "closure_source_limit",
        "closure_target_distance2",
        "closure_distance_limit2",
        "boss_choice_count",
        "reward_choice_count",
        "budget_check_interval",
        "reserve_from_growth_count"
      ],
      "properties": {
        "growth_frontier_limit": {
          "type": "integer",
          "minimum": 1
        },
        "growth_choice_count": {
          "type": "integer",
          "minimum": 1
        },
        "close_attempts": {
          "type": "integer",
          "minimum": 0
        },
        "close_depth": {
          "type": "integer",
          "minimum": 1
        },
        "closure_beam_width": {
          "type": "integer",
          "minimum": 1
        },
        "candidate_expansion_budget": {
          "type": "integer",
          "minimum": 1
        },
        "per_seed_timeout_seconds": {
          "anyOf": [
            {
              "type": "number",
              "exclusiveMinimum": 0
            },
            {
              "type": "null"
            }
          ]
        },
        "max_growth_backtracks": {
          "type": "integer",
          "minimum": 0
        },
        "max_rewind_depth": {
          "type": "integer",
          "minimum": 1
        },
        "max_terminal_states": {
          "type": "integer",
          "minimum": 1
        },
        "max_layout_repairs": {
          "type": "integer",
          "minimum": 0
        },
        "growth_shortlist": {
          "type": "integer",
          "minimum": 1
        },
        "closure_source_limit": {
          "type": "integer",
          "minimum": 1
        },
        "closure_target_distance2": {
          "type": "integer",
          "minimum": 1
        },
        "closure_distance_limit2": {
          "type": "integer",
          "minimum": 1
        },
        "boss_choice_count": {
          "type": "integer",
          "minimum": 1
        },
        "reward_choice_count": {
          "type": "integer",
          "minimum": 1
        },
        "budget_check_interval": {
          "type": "integer",
          "minimum": 1
        },
        "reserve_from_growth_count": {
          "type": "integer",
          "minimum": 1
        }
      }
    },
    "seals": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "thickness_pixels"
      ],
      "properties": {
        "thickness_pixels": {
          "type": "number",
          "exclusiveMinimum": 0
        }
      }
    },
    "diversity": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "exit_decay",
        "repeat_power",
        "early_fraction",
        "late_fraction",
        "late_exit_weight",
        "reward_repeat_penalty",
        "merge_bonus",
        "multi_return_bonus",
        "branch_length_bonus",
        "connector_repeat_penalty",
        "branch_depth",
        "branch_beam_width",
        "branch_source_limit",
        "branch_completion_limit",
        "growth_poses_per_module",
        "growth_score_slack"
      ],
      "properties": {
        "exit_decay": {
          "type": "number",
          "minimum": 0,
          "maximum": 1
        },
        "repeat_power": {
          "type": "number",
          "minimum": 0
        },
        "early_fraction": {
          "type": "number",
          "minimum": 0,
          "maximum": 1
        },
        "late_fraction": {
          "type": "number",
          "minimum": 0,
          "maximum": 1
        },
        "late_exit_weight": {
          "type": "number",
          "minimum": 0,
          "maximum": 1
        },
        "reward_repeat_penalty": {
          "type": "number",
          "minimum": 0
        },
        "merge_bonus": {
          "type": "number",
          "minimum": 0
        },
        "multi_return_bonus": {
          "type": "number",
          "minimum": 0
        },
        "branch_length_bonus": {
          "type": "number",
          "minimum": 0
        },
        "connector_repeat_penalty": {
          "type": "number",
          "minimum": 0
        },
        "branch_depth": {
          "type": "integer",
          "minimum": 1
        },
        "branch_beam_width": {
          "type": "integer",
          "minimum": 1
        },
        "branch_source_limit": {
          "type": "integer",
          "minimum": 1
        },
        "branch_completion_limit": {
          "type": "integer",
          "minimum": 1
        },
        "growth_poses_per_module": {
          "type": "integer",
          "minimum": 1
        },
        "growth_score_slack": {
          "type": "number",
          "minimum": 0
        }
      }
    },
    "planning": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "candidate_pool_limit",
        "direct_scan_limit",
        "merge_target_limit",
        "bridge_matches_per_front"
      ],
      "properties": {
        "candidate_pool_limit": {
          "type": "integer",
          "minimum": 1
        },
        "direct_scan_limit": {
          "type": "integer",
          "minimum": 1
        },
        "merge_target_limit": {
          "type": "integer",
          "minimum": 1
        },
        "bridge_matches_per_front": {
          "type": "integer",
          "minimum": 1
        }
      }
    },
    "topology": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "backbone_min",
        "backbone_max",
        "domain_limit",
        "reward_modes"
      ],
      "properties": {
        "backbone_min": {
          "type": "integer",
          "minimum": 2
        },
        "backbone_max": {
          "type": "integer",
          "minimum": 2
        },
        "domain_limit": {
          "type": "integer",
          "minimum": 1
        },
        "reward_modes": {
          "type": "array",
          "minItems": 1,
          "items": {
            "type": "string",
            "enum": [
              "multi_return",
              "forward_merge"
            ]
          }
        }
      }
    },
    "construction": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "anchor_growth_count",
        "max_anchor_growth_count",
        "bypass_depth",
        "macro_candidate_limit",
        "core_loop_policy"
      ],
      "properties": {
        "core_loop_policy": {
          "type": "string",
          "enum": [
            "path_gain",
            "legacy"
          ]
        },
        "anchor_growth_count": {
          "type": "integer",
          "minimum": 2
        },
        "max_anchor_growth_count": {
          "type": "integer",
          "minimum": 2
        },
        "bypass_depth": {
          "type": "integer",
          "enum": [
            1,
            2
          ]
        },
        "macro_candidate_limit": {
          "type": "integer",
          "minimum": 1
        }
      }
    }
  }
}
